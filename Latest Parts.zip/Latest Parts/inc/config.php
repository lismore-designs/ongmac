<?php
    $_dealer_name = "Ongmac Motorcycles";
    $_dealer_key = '23bc742b-2a11-4873-874b-7b4fcc5d7eab';
    $_product_key_honda = '2163ef55-5db0-4300-ba58-ea4303df5f46';
    $_configured_product_types = "MB";
?>