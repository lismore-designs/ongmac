</div><div class="text-right"><hr />&copy; SuperbLab <?php echo date('Y');?></div><br>
</div>
<script type="text/javascript" src="../symbiotic/jquery.min.js"></script>
<script type="text/javascript" src="../symbiotic/bootstrap.min.js"></script>
<script type="text/javascript" src="../symbiotic/cart.js"></script>
</body>
</html>