<div class="col-md-3">
<ul class="nav nav-stacked">
<li><a href="<?php echo $setting['website_url'];?>">Home</a></li>
<li><a href="index.php">Overview</a></li>
<li><a href="#" class="showAjaxCart" >Cart</a></li>
<li><a href="orders.php">My Orders</a></li>
<li><a href="order-status.php">Order Status</a></li>
<li><a href="addresses.php">My Addresses</a></li>
<li><a href="account.php">My Account</a></li>
<li><a href="sign-in.php?action=signout">Sign out</a><li>
</ul>
</div>
<div class="col-md-9">