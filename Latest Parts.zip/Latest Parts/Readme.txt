Chnage the databsae connection info
--------------------------------------------
Path :- Latest Parts\symbiotic\admin\include\

<?php

DEFINE('DBNAME','db_name'); 

DEFINE('DBUSER','db_user'); 

DEFINE('DBPWD','db_password'); 

DEFINE('DBHOST','db_host'); 

DEFINE('PFX','sym_'); 

?>
------------------------------------------------------------

Changes In hondaepc.js

Line Number :- 448,458,506

Just Replance the "http://parts.relaxcode.com" to the domain name where you upload the files.


Note:- if you are unable to find the lines then find "http://parts.relaxcode.com" and replace it.

---------------------------------------------------

