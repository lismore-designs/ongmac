<?php

DEFINE('DBNAME','honda_parts1'); 

DEFINE('DBUSER','hondaparts_1'); 

DEFINE('DBPWD','hondaparts_2'); 

DEFINE('DBHOST','relaxcodecom.ipagemysql.com'); 

DEFINE('PFX','sym_'); 


 
?>