<?php 

// Database Settings

DEFINE('DBNAME','orders');
DEFINE('DBUSER','admin');
DEFINE('DBPWD','admin');
DEFINE('DBHOST','localhost');
DEFINE('PFX','sym_');
//




?>