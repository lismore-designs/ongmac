<?php 

$gateways = array();
$gateways[] = array(
'name' => 'PayPal',
'file' => 'paypal.php'
);
$gateways[] = array(
'name' => 'Money Bookers',
'file' => 'skrill.php'
);
$gateways[] = array(
'name' => 'CCAvenue',
'file' => 'cc.php'
);
$gateways[] = array(
'name' => 'Techprocess',
'file' => 'tp.php'
);
$gateways[] = array(
'name' => 'Cash on Delivery',
'file' => 'cash.php'
);
$gateways[] = array(
'name' => 'Store Pickup',
'file' => 'pickup.php'
);

$gateways[] = array(
'name' => 'Bank Tranfer',
'file' => 'bank.php',
'info' => 'Your Bank account details here'
);

?>