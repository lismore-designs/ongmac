<?php
class Auth{
	var $error = '';
	public function is_loggedin(){
		
		if(isset($_SESSION['customerauth']) && isset($_SESSION['curr_user']) && isset($_SESSION['token'])){
		$checksum = md5($_SESSION['curr_user'] . 'symbiotic' . date('ymd'));
			if($checksum == $_SESSION['token']){
			return true;
			}
			return false;
		}
		return false;	
	}
public function login($email,$password){
global $crypt;
$password = base64_encode($password);
	$result = mysql_query("SELECT * FROM  " . PFX . "customers WHERE active = 1 AND email = '$email' AND password = '$password' ");
	while($rows = mysql_fetch_assoc($result)){	
		$_SESSION['curr_user'] = $rows['email'];
		$_SESSION['uid'] = $crypt->encrypt($rows['id']);
		$_SESSION['token'] = md5($rows['email'] . 'symbiotic' . date('ymd'));
		$_SESSION['customerauth'] = true;
		$this->msg = 'Login Successfull';
		return true;
	}
	$this->error = 'Invalid Username / Password';
	return false;
}
public function signout(){
	unset($_SESSION['curr_user']);
	unset($_SESSION['basket']);
	//session_start(); // Used Till V1.1
	header("location:index.php");
	exit;
}	
}

?>